document.addEventListener("DOMContentLoaded", () => {
  document.querySelector("p").textContent = "Welcome to the KORED quiz. Let's begin!";
});